package ua.vinnitsa.power

import android.content.Context
import androidx.work.*
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.util.concurrent.TimeUnit

object Refresher {
    val GROUPS = listOf("1.1", "1.2", "2.1", "2.2", "3.1", "3.2", "4.1", "4.2", "5.1", "5.2", "6.1", "6.2")
    private const val BASE = "https://raw.githubusercontent.com/Svitlobot-official/timetables/main/vinnytsia/"

    fun fetchGroup(group: String): String? = try {
        val con = URL("$BASE$group.json").openConnection() as HttpURLConnection
        con.connectTimeout = 15000; con.readTimeout = 15000
        if (con.responseCode == 200) con.inputStream.bufferedReader().readText() else null
    } catch (e: Exception) { null }

    /** Скачивает график, пересоздаёт напоминания. Не вызывать из главного потока. */
    fun refresh(c: Context, notifyChange: Boolean = true): String {
        val p = Scheduler.prefs(c)
        val group = p.getString("group", null) ?: return "Автооновлення не налаштовано"
        return try {
            val con = URL("$BASE$group.json").openConnection() as HttpURLConnection
            con.connectTimeout = 15000; con.readTimeout = 15000
            if (con.responseCode != 200) return "Помилка завантаження (HTTP ${con.responseCode})"
            val json = con.inputStream.bufferedReader().readText()
            val changed = Scheduler.update(c, Scheduler.parseSvitlobot(json))
            if (changed && notifyChange) Notifier.show(c, "Графік змінено", "Графік відключень оновився, нагадування перераховано")
            val msg = "Оновлено о " + java.time.LocalTime.now(Scheduler.KYIV).toString().take(5)
            p.edit().putString("updated", msg).apply()
            msg
        } catch (e: Exception) { "Помилка: ${e.message}" }
    }

    private fun covered(iv: List<IntArray>, h: Int): Boolean {
        var mins = 0
        for (p in iv) { val s = maxOf(p[0], h * 60); val e = minOf(p[1], h * 60 + 60); if (e > s) mins += e - s }
        return mins >= 30
    }

    /** (совпало часов, всего сравнено) для группы; null если данных группы нет. */
    fun score(group: String, scraped: Map<LocalDate, BooleanArray>): Pair<Int, Int>? {
        val json = fetchGroup(group) ?: return null
        val days = try { Scheduler.parseSvitlobot(json) } catch (e: Exception) { return null }
        var ok = 0; var total = 0
        for ((date, mask) in scraped) {
            val iv = days[date] ?: continue
            for (h in 0 until 24) { total++; if (mask[h] == covered(iv, h)) ok++ }
        }
        return ok to total
    }

    /** Находит группу, чьи часы отключений лучше всего совпали с таблицей с сайта. */
    fun detectGroup(scraped: Map<LocalDate, BooleanArray>): String? {
        var best: String? = null; var bestScore = 0
        for (g in GROUPS) {
            val s = score(g, scraped) ?: continue
            if (s.first > bestScore) { bestScore = s.first; best = g }
        }
        return best
    }

    fun schedulePeriodic(c: Context) {
        val req = PeriodicWorkRequestBuilder<RefreshWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("refresh", ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}

class RefreshWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val r = Refresher.refresh(applicationContext)
        return if (r.startsWith("Помилка")) Result.retry() else Result.success()
    }
}
