package ua.vinnitsa.power

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.OvershootInterpolator
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.json.JSONTokener
import java.time.LocalDate
import java.time.ZonedDateTime

private object Pal {
    val GRAY = 0xFF9A93BD.toInt()
    val GREEN = 0xFF4ADE80.toInt()
    val RED = 0xFFFF5C5C.toInt()
    val WHITE = Color.WHITE
}

private class Scraped(val masks: Map<LocalDate, BooleanArray>, val days: Days, val queue: String?, val addr: String)

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var rain: RainView
    private lateinit var holder: FrameLayout
    private var web: WebView? = null
    private var onAddress = false
    private var saving = false
    private var found: Scraped? = null
    private var confirmCard: LinearLayout? = null
    private var confirmText: TextView? = null
    private var tickAction: (() -> Unit)? = null

    private val tick = object : Runnable {
        override fun run() { tickAction?.invoke(); ui.postDelayed(this, 30_000) }
    }
    private val poll = object : Runnable {
        override fun run() { if (onAddress) { scrape(); ui.postDelayed(this, 2000) } }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        Notifier.ensure(this)
        rain = RainView(this)
        holder = FrameLayout(this)
        val root = FrameLayout(this)
        root.addView(rain, FrameLayout.LayoutParams(-1, -1))
        root.addView(holder, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        Refresher.schedulePeriodic(this)
        if (Scheduler.prefs(this).getString("address", null) == null) showAddress() else showMain()
    }

    override fun onResume() {
        super.onResume()
        Scheduler.scheduleAll(this)
        if (!onAddress && tickAction != null) { ui.removeCallbacks(tick); ui.post(tick) }
    }

    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        web?.destroy()
        super.onDestroy()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val has = Scheduler.prefs(this).getString("address", null) != null
        if (onAddress && web?.canGoBack() == true) web?.goBack()
        else if (onAddress && has) showMain()
        else super.onBackPressed()
    }

    // ================= UI-хелперы =================
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density

    private fun label(t: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = t; tv.textSize = sp; tv.setTextColor(color)
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(16), dp(16), dp(16), dp(16))
        val bg = GradientDrawable()
        bg.setColor(0xCC141022.toInt()); bg.cornerRadius = dpf(22f); bg.setStroke(dp(1), 0x33A78BFA)
        l.background = bg
        l.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
        return l
    }

    private fun button(text: String, filled: Boolean, onClick: () -> Unit): TextView {
        val shape = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            if (filled) intArrayOf(0xFF7C3AED.toInt(), 0xFFB05CF6.toInt()) else intArrayOf(0x1AFFFFFF, 0x1AFFFFFF)
        )
        shape.cornerRadius = dpf(18f)
        if (!filled) shape.setStroke(dp(1), 0x66A78BFA)
        val mask = GradientDrawable()
        mask.setColor(Color.WHITE); mask.cornerRadius = dpf(18f)
        val t = TextView(this)
        t.text = text; t.textSize = 15f; t.setTextColor(Color.WHITE); t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(14), dp(14), dp(14))
        t.background = RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), shape, mask)
        t.isClickable = true
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(3f)).start()
            }
            false
        }
        t.setOnClickListener { onClick() }
        t.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        return t
    }

    private fun dayTitle(d: LocalDate): String {
        val names = arrayOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Нд")
        return names[d.dayOfWeek.value - 1] + " %02d.%02d".format(d.dayOfMonth, d.monthValue)
    }

    // ================= Головний екран =================
    private fun showMain() {
        onAddress = false
        ui.removeCallbacks(poll)
        rain.visibility = View.VISIBLE
        holder.removeAllViews()
        val p = Scheduler.prefs(this)

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(14), dp(18), dp(30))
        scroll.addView(col, ViewGroup.LayoutParams(-1, -2))
        holder.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        // шапка
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val ico = ImageView(this)
        ico.setImageResource(R.mipmap.ic_launcher)
        head.addView(ico, LinearLayout.LayoutParams(dp(46), dp(46)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(12), 0, 0, 0)
        titles.addView(label("VoltAlert", 24f, Pal.WHITE, true))
        titles.addView(label(p.getString("address", "") ?: "", 13f, Pal.GRAY))
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        col.addView(head)

        // статус
        val statusCard = card()
        val tvState = label("", 26f, Pal.WHITE, true)
        val tvSub = label("", 14f, Pal.GRAY)
        statusCard.addView(tvState); statusCard.addView(tvSub)
        col.addView(statusCard)

        // график
        val sv = ScheduleView(this)

        fun updateStatus() {
            val st = Scheduler.state(this)
            if (st == null) {
                tvState.text = "Немає даних"; tvState.setTextColor(Pal.GRAY)
                tvSub.text = "Натисніть «Оновити»"
                return
            }
            val now = System.currentTimeMillis()
            val at = st.changeAt
            if (st.off) {
                tvState.text = "Світла немає"; tvState.setTextColor(Pal.RED)
                tvSub.text = if (at != null) "Увімкнуть о ${Scheduler.whenText(at)} · через ${Scheduler.dur(at - now)}" else "Час увімкнення невідомий"
            } else {
                tvState.text = "Світло є"; tvState.setTextColor(Pal.GREEN)
                tvSub.text = if (at != null) "Відключення о ${Scheduler.whenText(at)} · через ${Scheduler.dur(at - now)}" else "Найближчих відключень немає"
            }
        }

        fun renderSchedule() {
            val days = Scheduler.loadDays(this)
            val today = LocalDate.now(Scheduler.KYIV)
            val tom = today.plusDays(1)
            sv.cols = listOf(
                ScheduleView.Col(dayTitle(today), "сьогодні", days[today]),
                ScheduleView.Col(dayTitle(tom), "завтра", days[tom])
            )
            val z = ZonedDateTime.now(Scheduler.KYIV)
            sv.nowMin = z.hour * 60 + z.minute
            sv.invalidate()
        }

        val tvUpdated = label(p.getString("updated", "") ?: "", 12f, Pal.GRAY)
        tvUpdated.gravity = Gravity.CENTER
        tvUpdated.setPadding(0, dp(10), 0, 0)

        // кнопки
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val bCalc = button("Розрахувати час", true) { showCalc() }
        val bRefresh = button("Оновити", false) {
            tvUpdated.text = "Оновлення…"
            refreshNow { r -> tvUpdated.text = r }
        }
        (bCalc.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; rightMargin = dp(6) }
        (bRefresh.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; leftMargin = dp(6) }
        row.addView(bCalc); row.addView(bRefresh)
        col.addView(row)

        // графік-картка
        val gCard = card()
        gCard.addView(label("Графік відключень", 17f, Pal.WHITE, true))
        val legend = SpannableStringBuilder("■ немає світла     ■ є світло")
        legend.setSpan(ForegroundColorSpan(0xFFFF5A36.toInt()), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        legend.setSpan(ForegroundColorSpan(0xFF3A2F5E.toInt()), 17, 18, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val tvLegend = label("", 12f, Pal.GRAY)
        tvLegend.text = legend
        tvLegend.setPadding(0, dp(4), 0, dp(10))
        gCard.addView(tvLegend)
        gCard.addView(sv, LinearLayout.LayoutParams(-1, -2))
        col.addView(gCard)

        // сповіщення
        val nCard = card()
        nCard.addView(label("Сповіщення", 17f, Pal.WHITE, true))
        notifBlock(nCard, "Про відключення", true)
        notifBlock(nCard, "Про увімкнення", false)
        val soundRow = LinearLayout(this)
        soundRow.orientation = LinearLayout.HORIZONTAL
        val bTest = button("Перевірити", false) {
            Notifier.show(this, "Перевірка", "Так звучатимуть попередження про світло")
        }
        val bSound = button("Звук", false) {
            Notifier.ensure(this)
            try {
                startActivity(
                    Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                        .putExtra(Settings.EXTRA_CHANNEL_ID, Notifier.CH)
                )
            } catch (e: Exception) { }
        }
        (bTest.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; rightMargin = dp(6) }
        (bSound.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; leftMargin = dp(6) }
        soundRow.addView(bTest); soundRow.addView(bSound)
        nCard.addView(soundRow)
        nCard.addView(button("Робота у фоні", false) { setupBackground() })
        col.addView(nCard)

        col.addView(button("Змінити адресу", false) { showAddress() })
        col.addView(tvUpdated)

        tickAction = { updateStatus(); renderSchedule() }
        tickAction?.invoke()
        ui.removeCallbacks(tick); ui.post(tick)
        refreshNow { r -> tvUpdated.text = r }
    }

    private val leads = intArrayOf(5, 10, 15, 20, 30, 45, 60, 90, 120, 180, 240)

    private fun notifBlock(parent: LinearLayout, title: String, off: Boolean) {
        val p = Scheduler.prefs(this)
        val kEn = if (off) "notif_off" else "notif_on"
        val kLead = if (off) "lead_off" else "lead_on"
        val enabled = p.getBoolean(kEn, true)

        val sw = Switch(this)
        sw.text = title; sw.textSize = 16f; sw.setTextColor(Color.WHITE); sw.isChecked = enabled
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(0xFFC4B5FD.toInt(), 0xFF9CA3AF.toInt()))
        sw.trackTintList = ColorStateList(states, intArrayOf(0x887C3AED.toInt(), 0x44FFFFFF))
        sw.setPadding(0, dp(12), 0, dp(4))

        val sp = Spinner(this)
        val labels = leads.map { "За " + Scheduler.leadText(it) }
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = ad
        val cur = p.getInt(kLead, 30)
        sp.setSelection(leads.indexOf(cur).let { if (it < 0) 4 else it }, false)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (leads[pos] != p.getInt(kLead, 30)) {
                    p.edit().putInt(kLead, leads[pos]).apply()
                    Scheduler.scheduleAll(this@MainActivity)
                }
            }
            override fun onNothingSelected(a: AdapterView<*>?) { }
        }
        sp.isEnabled = enabled; sp.alpha = if (enabled) 1f else 0.4f
        sw.setOnCheckedChangeListener { _, on ->
            p.edit().putBoolean(kEn, on).apply()
            sp.isEnabled = on; sp.alpha = if (on) 1f else 0.4f
            Scheduler.scheduleAll(this)
        }

        val line = LinearLayout(this)
        line.orientation = LinearLayout.HORIZONTAL
        line.gravity = Gravity.CENTER_VERTICAL
        line.addView(label("Попередити", 14f, Pal.GRAY), LinearLayout.LayoutParams(0, -2, 1f))
        line.addView(sp, LinearLayout.LayoutParams(-2, -2))
        parent.addView(sw, LinearLayout.LayoutParams(-1, -2))
        parent.addView(line, LinearLayout.LayoutParams(-1, -2))
    }

    private fun refreshNow(done: ((String) -> Unit)? = null) {
        Thread {
            val r = Refresher.refresh(this, false)
            runOnUiThread { if (!isFinishing) { done?.invoke(r); tickAction?.invoke() } }
        }.start()
    }

    private fun showCalc() {
        val days = Scheduler.loadDays(this)
        val st = Scheduler.state(this)
        val now = System.currentTimeMillis()
        val sb = StringBuilder()
        if (st == null) {
            sb.append("Даних про графік ще немає.")
        } else {
            val at = st.changeAt
            if (st.off) {
                sb.append("Зараз світла немає.\n")
                if (at != null) sb.append("Увімкнуть о ${Scheduler.whenText(at)} — через ${Scheduler.dur(at - now)}.\n")
                val later = st.laterStart
                if (later != null) sb.append("Потім відключення о ${Scheduler.whenText(later)}.\n")
            } else {
                sb.append("Зараз світло є.\n")
                if (at != null) sb.append("Відключення о ${Scheduler.whenText(at)} — через ${Scheduler.dur(at - now)}.\n")
                else sb.append("Найближчих відключень немає.\n")
            }
        }
        val today = LocalDate.now(Scheduler.KYIV)
        fun total(d: LocalDate): String {
            val m = Scheduler.minutesOff(days[d]) ?: return "графік ще не опубліковано"
            return Scheduler.dur(m * 60_000L)
        }
        sb.append("\nБез світла сьогодні: ").append(total(today))
        sb.append("\nБез світла завтра: ").append(total(today.plusDays(1)))
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Розрахунок часу")
            .setMessage(sb.toString())
            .setPositiveButton("Добре", null)
            .show()
    }

    private fun setupBackground() {
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                return
            }
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                return
            }
            Toast.makeText(this, "Усе налаштовано ✓", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) { }
        }
    }

    // ================= Екран адреси =================
    private fun ensureWeb(): WebView {
        web?.let { return it }
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String?) { v.evaluateJavascript(DARK_JS, null) }
        }
        web = w
        return w
    }

    private fun showAddress() {
        onAddress = true; saving = false; found = null
        ui.removeCallbacks(tick)
        rain.visibility = View.GONE
        holder.removeAllViews()
        val hasAddr = Scheduler.prefs(this).getString("address", null) != null

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), dp(12), dp(14), dp(12))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.addView(label("Ваша адреса", 22f, Pal.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        if (hasAddr) {
            val close = button("Назад", false) { showMain() }
            (close.layoutParams as LinearLayout.LayoutParams).apply { topMargin = 0; width = -2 }
            close.setPadding(dp(20), dp(8), dp(20), dp(8))
            bar.addView(close)
        }
        col.addView(bar)
        val hint = label("Вкажіть місто, вулицю та будинок і натисніть «Перевірити адресу»", 13f, Pal.GRAY)
        hint.setPadding(0, dp(6), 0, dp(10))
        col.addView(hint)

        val frame = FrameLayout(this)
        val fbg = GradientDrawable()
        fbg.setColor(Color.BLACK); fbg.cornerRadius = dpf(18f)
        frame.background = fbg
        frame.clipToOutline = true
        frame.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dpf(18f)) }
        }
        val w = ensureWeb()
        (w.parent as? ViewGroup)?.removeView(w)
        frame.addView(w, FrameLayout.LayoutParams(-1, -1))
        col.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        val cc = card()
        cc.visibility = View.GONE
        val ct = label("", 14f, Pal.WHITE)
        cc.addView(ct)
        cc.addView(button("Зберегти адресу", true) { found?.let { saveAddress(it) } })
        col.addView(cc)
        confirmCard = cc; confirmText = ct

        holder.addView(col, FrameLayout.LayoutParams(-1, -1))
        w.loadUrl(URL)
        ui.removeCallbacks(poll); ui.postDelayed(poll, 2000)
    }

    private fun scrape() {
        val w = web ?: return
        w.evaluateJavascript(DARK_JS, null)
        w.evaluateJavascript(SCRAPE_JS) { raw ->
            var sc: Scraped? = null
            try {
                val s = JSONTokener(raw ?: "null").nextValue()
                if (s is String) sc = parseScraped(JSONObject(s))
            } catch (e: Exception) { }
            found = sc
            val cc = confirmCard; val ct = confirmText
            if (cc != null && ct != null && onAddress && !saving) {
                if (sc != null) {
                    ct.text = "Графік знайдено:\n" + sc.addr.ifBlank { "обрана адреса" }
                    cc.visibility = View.VISIBLE
                } else cc.visibility = View.GONE
            }
        }
    }

    private fun parseScraped(o: JSONObject): Scraped? {
        val heads = o.getJSONArray("heads")
        val rows = o.getJSONArray("rows")
        if (rows.length() == 0) return null
        val today = LocalDate.now(Scheduler.KYIV)
        val ncols = rows.getJSONObject(0).getJSONArray("v").length()
        if (ncols == 0) return null
        val dates = ArrayList<LocalDate>()
        for (i in 0 until ncols) {
            var d = today.plusDays(i.toLong())
            if (i < heads.length()) {
                val m = Regex("(\\d{1,2})\\.(\\d{1,2})").find(heads.getString(i))
                if (m != null) {
                    val day = m.groupValues[1].toInt(); val mo = m.groupValues[2].toInt()
                    var y = today.year
                    if (mo == 1 && today.monthValue == 12) y++
                    if (mo == 12 && today.monthValue == 1) y--
                    try { d = LocalDate.of(y, mo, day) } catch (e: Exception) { }
                }
            }
            dates.add(d)
        }
        val masks = HashMap<LocalDate, BooleanArray>()
        for (d in dates) masks[d] = BooleanArray(24)
        for (r in 0 until rows.length()) {
            val row = rows.getJSONObject(r)
            val hour = row.getInt("h")
            val v = row.getJSONArray("v")
            if (hour !in 0..23) continue
            for (i in 0 until minOf(ncols, v.length())) masks[dates[i]]!![hour] = v.getInt(i) == 2
        }
        val days = Days()
        for ((d, mask) in masks) {
            val list = ArrayList<IntArray>()
            var start = -1
            for (h in 0..24) {
                val on = h < 24 && mask[h]
                if (on && start < 0) start = h
                if (!on && start >= 0) { list.add(intArrayOf(start * 60, h * 60)); start = -1 }
            }
            days[d] = list
        }
        val q = if (o.isNull("queue")) null else o.getString("queue")
        return Scraped(masks, days, q, o.optString("addr", ""))
    }

    private fun saveAddress(sc: Scraped) {
        if (saving) return
        saving = true
        confirmText?.text = "Зберігаю…"
        Thread {
            try {
                var group = sc.queue?.takeIf { it in Refresher.GROUPS }
                if (group != null) {
                    val s = Refresher.score(group, sc.masks)
                    if (s != null && s.second > 0 && s.first < s.second * 0.85) group = null
                }
                if (group == null) group = Refresher.detectGroup(sc.masks)
                val ed = Scheduler.prefs(this).edit()
                ed.putString("address", sc.addr.ifBlank { "Моя адреса" })
                if (group != null) ed.putString("group", group) else ed.remove("group")
                ed.apply()
                Scheduler.update(this, sc.days)
                if (group != null) Refresher.refresh(this, false)
                Refresher.schedulePeriodic(this)
                runOnUiThread {
                    showMain()
                    val p = Scheduler.prefs(this)
                    if (!p.getBoolean("bg_asked", false)) {
                        p.edit().putBoolean("bg_asked", true).apply()
                        setupBackground()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { saving = false; Toast.makeText(this, "Не вдалося зберегти: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    companion object {
        const val URL = "https://disconnection.voe.com.ua/"

        const val DARK_JS = """(function(){if(document.getElementById('va-dark'))return;var s=document.createElement('style');s.id='va-dark';s.innerHTML='html{filter:invert(.92) hue-rotate(180deg)!important;background:#fff!important}img,video{filter:invert(1) hue-rotate(180deg)}';document.head.appendChild(s);})()"""

        const val SCRAPE_JS = """(function(){try{
var tabs=document.querySelectorAll('table'),tb=null;
for(var i=0;i<tabs.length;i++){if(/Часові\s+проміжки/i.test(tabs[i].innerText)){tb=tabs[i];break;}}
if(!tb)return null;
function cls(el){
 var nodes=[el].concat(Array.prototype.slice.call(el.querySelectorAll('*')));
 for(var k=0;k<nodes.length;k++){
  var m=getComputedStyle(nodes[k]).backgroundColor.match(/[\d.]+/g);
  if(!m)continue;
  var r=+m[0],g=+m[1],b=+m[2],a=m.length>3?+m[3]:1;
  if(a<0.5)continue;
  if(r>200&&g>50&&g<165&&b<110)return 2;
  if(r>220&&g>=165&&b<110)return 1;
 }
 return 0;
}
var rows=tb.querySelectorAll('tr'),heads=[],data=[];
for(var i=0;i<rows.length;i++){
 var cells=rows[i].children;if(!cells.length)continue;
 var first=(cells[0].innerText||'').trim();
 var hm=first.match(/^(\d{1,2})\s*[-–]\s*(\d{1,2})$/);
 if(hm){var arr=[];for(var j=1;j<cells.length;j++)arr.push(cls(cells[j]));data.push({h:+hm[1],v:arr});}
 else if(/Часові/i.test(first)){for(var j=1;j<cells.length;j++)heads.push((cells[j].innerText||'').trim());}
}
if(!data.length)return null;
var inputs=document.querySelectorAll('input'),addr=[];
for(var i=0;i<inputs.length;i++){var v=(inputs[i].value||'').trim();var t=inputs[i].type;
 if(v&&t!=='hidden'&&t!=='radio'&&t!=='checkbox')addr.push(v);}
var q=(document.body.innerText||'').match(/(?:[Чч]ерг[аиу]|[Гг]руп[аиу])[^0-9\n]{0,20}(\d)\.(\d)/);
return JSON.stringify({heads:heads,rows:data,addr:addr.join(', '),queue:q?q[1]+'.'+q[2]:null});
}catch(e){return null;}})()"""
    }
}
